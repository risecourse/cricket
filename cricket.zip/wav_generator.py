import numpy as np
import scipy.io.wavfile
from scipy import signal as sg

Fs = 44100 # Sampling Rate
seconds = 20 # Duration (in seconds)
samples = seconds * Fs # Number of samples
x = np.arange(samples)

freq = [20, 50, 100, 200, 500, 1000, 2000, 5000]

for f in freq:
    y = np.sin(2 * np.pi * f * x / Fs)
    filename = "freq" + str(f) + ".wav"
    scipy.io.wavfile.write(filename, Fs, y)
